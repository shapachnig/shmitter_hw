import Stats from "./Stats.jsx";

const Sidebar = () => {
    return (
        <div className={'sidebar'}>
            <Stats/>
        </div>
    );
};

export default Sidebar;