const Avatar = ({size}) => {
    return (
        <img className={`user-avatar ${size ?? ''}`} src={'https://gravatar.com/avatar/000?d=monsterid'} alt="avatar" />
    );
};

export default Avatar;