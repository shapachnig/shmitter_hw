const Content = () => {
    return (
        <div className={'content'}>
            Main content here
        </div>
    );
};

export default Content;