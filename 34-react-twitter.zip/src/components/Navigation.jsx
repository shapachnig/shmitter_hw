import Avatar from "./Avatar.jsx";

const Navigation = () => {
    return (
        <div className={'nav'}>
            <Avatar size={'small'}/>
        </div>
    );
};

export default Navigation;